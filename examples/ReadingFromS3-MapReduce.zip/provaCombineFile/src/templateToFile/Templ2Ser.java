package templateToFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

import model.Page;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Node;

import rules.dom.TextElements;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class Templ2Ser {
	
	private static void addPageToTemplate (Map<String, Integer> nodeContent2occurrences, Page pagina){
		
		Integer uno = new Integer(1);
		
		//estraggo dalla pagina tutti i nodi testuali
		TextElements textElements = new TextElements(pagina);		
		Set<Node> tuttiNodi = textElements.getAllTextNodes();
			    		
		//conto le occorrenze di ogni nodo nella pagina
		Map<String, Integer> nodeCont2pageOcc = new HashMap<String, Integer>();
		for (Node nodo : tuttiNodi) {
			String content = nodo.getTextContent();
			if (Pattern.matches("[ \t\r\n\f]+", content)) {
				//do nothing (è un nodo che contiene solo spazi)
			} else if (nodeCont2pageOcc.containsKey(content)) {
				int occorrenze = nodeCont2pageOcc.get(content);
				occorrenze++;
				nodeCont2pageOcc.put(content, occorrenze);
			} else {
				nodeCont2pageOcc.put(content, 1);
			}
		}
		    		
		//seleziono i nodi "candidati" a essere di tipo template (che hanno una sola occorrenza nella pagina)
		//e li inserisco/aggiorno nella relativa mappa
		for (String content : nodeCont2pageOcc.keySet()) {
			if (nodeCont2pageOcc.get(content).equals(uno)) {
				if (nodeContent2occurrences.containsKey(content)) {
					int occorrenze = nodeContent2occurrences.get(content);
					occorrenze++;
					nodeContent2occurrences.put(content, occorrenze);
				} else {
					nodeContent2occurrences.put(content, 1);
				}
			}
		}
			
	}
	
	private static Set<String> getPivotNodesContent(int numeroPagine, Map<String, Integer> nodeContent2occurrences){
		//creo la lista di nodi pivot (che stimo essere di tipo template)
		Set<String> pivotNodesContent = new HashSet<String>();
		for (String content : nodeContent2occurrences.keySet()) {
			if (nodeContent2occurrences.get(content).doubleValue()/numeroPagine > 0.6) {
				pivotNodesContent.add(content);
			}
		}
		
		return pivotNodesContent;
	}
	
	private static Set<String> getTemplateNodesContent(AmazonS3Client s3client, String bucketName, int percentuale){
		
//		String bucketName = conf.get(S3_BUCKET_NAME);
		
		//elenco tutti i file contenuti nel bucket
		ObjectListing listing = s3client.listObjects(bucketName);
		List<S3ObjectSummary> listaFileSummary = listing.getObjectSummaries();
		while(listing.isTruncated()){
			listing = s3client.listNextBatchOfObjects(listing);
			listaFileSummary.addAll(listing.getObjectSummaries());
		}
		
		//creo la mappa con il conteggio delle occorrenze dei nodi nelle pagine
		Map<String, Integer> nodeContent2occurrences = new HashMap<String, Integer>();
		
		//leggo il "percentuale"% dei files
		for (int i = 0; i < (listaFileSummary.size()*percentuale)/100; i++){
			Random random = new Random();
			int randInt = random.nextInt(listaFileSummary.size());
			String key = listaFileSummary.get(randInt).getKey();
			S3Object file = s3client.getObject(bucketName, key);
			try {
				S3ObjectInputStream s3ois = file.getObjectContent();
				Page pagina = new Page(IOUtils.toString(s3ois, "UTF-8"));
				s3ois.close();
				
				//popolo la mappa
				addPageToTemplate(nodeContent2occurrences, pagina);
			} catch (IOException e) { e.printStackTrace(); }
		}
			
		return getPivotNodesContent((listaFileSummary.size()*percentuale)/100, nodeContent2occurrences);
	}

	public static void main(String[] args) {
		
		String nomeBucket = args[0];
		String nomeFileTemplate = args[1];
		
//		Configuration conf = context.getConfiguration();
//		String accessKeyId = conf.get("fs.s3n.awsAccessKeyId");
//		String secretAccessKey = conf.get("fs.s3n.awsSecretAccessKey");
		String accessKeyId = "AKIAIJEL62B7T7RMUWDQ";
        String secretAccessKey = "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";
        AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
		AmazonS3Client s3client = new AmazonS3Client(credentials);
		
		//calcolo il template sul 10% delle pagine
//		List<Page> pagineCasuali = getRandomPages(s3client, nomeBucket, 10);
//		Set<String> contentNodiTemplate = getTemplateNodesContent(pagineCasuali);
		Set<String> contentNodiTemplate = getTemplateNodesContent(s3client, nomeBucket, 10);
		
		//scrivo il template su file
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(contentNodiTemplate);
			byte[] buffer = baos.toByteArray();
			InputStream is = new ByteArrayInputStream(buffer);
			ObjectMetadata meta = new ObjectMetadata();
			meta.setContentLength(buffer.length);
			s3client.putObject(new PutObjectRequest("alf-emr", "template/"+nomeFileTemplate, is, meta));
			is.close();
			oos.close();
			baos.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
	}
		
//	private static List<Page> getRandomPages(AmazonS3Client s3client, String bucketName, int percentuale){
//		
//		//System.out.println("Start getting "+percentuale+"% pages");
////		String bucketName = conf.get(S3_BUCKET_NAME);
//		ObjectListing listing = s3client.listObjects(bucketName);
//		List<S3ObjectSummary> listaFileSummary = listing.getObjectSummaries();
//		while(listing.isTruncated()){
//			listing = s3client.listNextBatchOfObjects(listing);
//			listaFileSummary.addAll(listing.getObjectSummaries());
//		}
//		
//		List<Page> pageList = new LinkedList<Page>();
//		for (int i = 0; i < (listaFileSummary.size()*percentuale)/100; i++){
//			Random random = new Random();
//			int randInt = random.nextInt(listaFileSummary.size());
//			String key = listaFileSummary.get(randInt).getKey();
//			S3Object file = s3client.getObject(bucketName, key);
//			try {
//				S3ObjectInputStream s3ois = file.getObjectContent();
//				Page pagina = new Page(IOUtils.toString(s3ois, "UTF-8"));
//				s3ois.close();
//				pageList.add(pagina);
//			} catch (IOException e) { e.printStackTrace(); }
//			//System.out.print(i);
//		}
//		
//		//System.out.println();
//		//System.out.println("Finished getting "+percentuale+"% pages");
//		
//		return pageList;
//	}
//	
//	private static Set<String> getTemplateNodesContent(List<Page> pagine){
//		
//		//System.out.println("Start compunting template");
//		
//		Map<String, Integer> nodeContent2occurrences = new HashMap<String, Integer>();
//		Integer uno = new Integer(1);
//		
//		for (Page p : pagine) {
//			//estraggo dalla pagina tutti i nodi testuali
//			TextElements textElements = new TextElements(p);		
//			Set<Node> tuttiNodi = textElements.getAllTextNodes();
//				    		
//			//conto le occorrenze di ogni nodo nella pagina
//			Map<String, Integer> nodeCont2pageOcc = new HashMap<String, Integer>();
//			for (Node nodo : tuttiNodi) {
//				String content = nodo.getTextContent();
//				if (Pattern.matches("[ \t\r\n\f]+", content)) {
//					//do nothing (è un nodo che contiene solo spazi)
//				} else if (nodeCont2pageOcc.containsKey(content)) {
//					int occorrenze = nodeCont2pageOcc.get(content);
//					occorrenze++;
//					nodeCont2pageOcc.put(content, occorrenze);
//				} else {
//					nodeCont2pageOcc.put(content, 1);
//				}
//			}
//			    		
//			//seleziono i nodi "candidati" a essere di tipo template (che hanno una sola occorrenza nella pagina)
//			//e li inserisco/aggiorno nella relativa mappa
//			for (String content : nodeCont2pageOcc.keySet()) {
//				if (nodeCont2pageOcc.get(content).equals(uno)) {
//					if (nodeContent2occurrences.containsKey(content)) {
//						int occorrenze = nodeContent2occurrences.get(content);
//						occorrenze++;
//						nodeContent2occurrences.put(content, occorrenze);
//					} else {
//						nodeContent2occurrences.put(content, 1);
//					}
//				}
//			}
//			
//		}
//		
//		//creo la lista di nodi pivot (che stimo essere di tipo template)
//		Set<String> pivotNodesContent = new HashSet<String>();
//		for (String content : nodeContent2occurrences.keySet()) {
//			if (nodeContent2occurrences.get(content).doubleValue()/pagine.size() > 0.6) {
//				pivotNodesContent.add(content);
//			}
//		}
//		
//		//System.out.println("Finished compunting template");
//				
//		return pivotNodesContent;
//	}

}
