package FindNotRapresented;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;

import com.atlantbh.hadoop.s3.io.S3ObjectInputFormat;

public class CFtoSFnr {
	
	static String S3_BUCKET_NAME = "s3.bucket.name";
	static String S3_KEY_PREFIX = "s3.key.prefix";
	
	/**
	 * Number of files to get from S3 in single request. Default value is 100
	 */
	static String S3_MAX_KEYS = "s3.max.keys";
	
	static String S3_NUM_OF_KEYS_PER_MAPPER = "s3.input.numOfKeys";
	static String S3_NUM_OF_MAPPERS = "s3.input.numOfMappers";


	public static void main(String[] args) throws Exception {
		
		String nomeBucket = args[0];
		String inputPath = "s3n://"+nomeBucket;
		String outputPath = args[1];
		int numeroChiavi = Integer.parseInt(args[2]);
		String rulesPath = args[3]; //in questo caso è il nome del file .ser contentente il rulesSet
		String prefisso = "";
		int numeroParametri = args.length;
		if (numeroParametri > 4) {
			prefisso = args[4];
		}	
		
		// Get the default configuration object
		Configuration conf = new Configuration();
		
		// Add resources
		conf.addResource("hdfs-default.xml");
		conf.addResource("hdfs-site.xml");
		conf.addResource("mapred-default.xml");
		conf.addResource("mapred-site.xml");
		
		conf.set(S3_BUCKET_NAME, nomeBucket);
		conf.set(S3_KEY_PREFIX, prefisso);
		conf.setInt(S3_NUM_OF_KEYS_PER_MAPPER, numeroChiavi);
		
		Job job = new Job(conf); //NOTA: Job si crea una copia di conf, da qui in poi usare job.getConfiguration() invece di conf
		job.setJobName("CFtoSFnr");
		
		//cacheRules(conf); //copio le regole su HDFS
		DistributedCache.addCacheFile(new Path("s3n://alf-emr/rules/"+rulesPath).toUri(), job.getConfiguration());
				
		job.setMapOutputKeyClass(Text.class); //NOTA: S3ObjectWritable è usabile solo come input
        job.setMapOutputValueClass(MapWritable.class);
		
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(MapWritable.class);	

        job.setMapperClass(MapCFtoSFnr.class);
	    job.setReducerClass(ReduceToSFnr.class);
		
	    job.setInputFormatClass(S3ObjectInputFormat.class);
        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        
		// Set the input path
        CombineFileInputFormat.setInputPaths(job, inputPath);
		// Set the output path
        SequenceFileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Set the jar file to run
		job.setJarByClass(CFtoSFnr.class);
		
		// Set the number of Reducers
		job.setNumReduceTasks(1);
		
		// Submit the job
		job.waitForCompletion(true);

	}

}
