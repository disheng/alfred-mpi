package FindNotRapresented;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;


public class ReduceToSFnr extends Reducer<Text,MapWritable,Text,MapWritable> { //deve solo aggregare risultati
	
	private Text textVuoto; //mi identifica le mappe di valori nulli in ingresso
	private Text textNull; //identifica la mappa dei valori nulli in uscita
	private MapWritable rule2null;
	private MapWritable mapVuoto;
		
	@Override
	protected void setup(Context context) {
		
		//inizializzo i textXxx
		this.textVuoto = new Text("");
		this.textNull = new Text("Null");
		
		this.mapVuoto = new MapWritable();
				
	}
	
	
	@Override
	protected void cleanup(Context context) {
		
		//scrivo la mappa dei valori nulli
		try {			
			
			context.write(this.textNull, this.rule2null);	
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
						
	}
		
	
	@Override
	public void reduce(Text key, Iterable<MapWritable> mappe, Context context) throws IOException, InterruptedException {
		
		if (!key.equals(this.textVuoto)) {
			
			context.write(key, this.mapVuoto);
	        
		} else {
			
			//aggrego i null			
			for (MapWritable mappa : mappe) {
				if (this.rule2null == null) {
					//inizializzo rule2null con la prima mappa ricevuta dai mapper
					this.rule2null = new MapWritable(mappa);
				} else {
					for (Writable regola : mappa.keySet()) {
						IntWritable newValue = (IntWritable)mappa.get((Text)regola);
						IntWritable oldValue = (IntWritable)this.rule2null.get((Text)regola);
						oldValue.set(oldValue.get() + newValue.get());
					}
				}
			}
			
		}
        
    }
	
}