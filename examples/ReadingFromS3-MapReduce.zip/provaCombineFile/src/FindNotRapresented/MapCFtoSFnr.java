package FindNotRapresented;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import model.MaterializedRuleSet;
import model.Page;
import model.Rule;

import rules.xpath.XPathRule;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.StringUtils;

import com.atlantbh.hadoop.s3.io.S3ObjectSummaryWritable;
import com.atlantbh.hadoop.s3.io.S3ObjectWritable;

public class MapCFtoSFnr extends Mapper<S3ObjectSummaryWritable,S3ObjectWritable,Text,MapWritable> {
     
	private MaterializedRuleSet rules;
	private List<List<Rule>> rulesSets;
	private MapWritable rule2null;
	private int contaPagine;
	
	
	@Override
	protected void setup(Context context) {
		
		//creo la mappa per i valori nulli
		this.rule2null = new MapWritable();
		
		//carico i rulesSets dalla DistributedCache
		this.rules = new MaterializedRuleSet();
		this.rulesSets = new LinkedList<List<Rule>>();
		
		Path[] cacheFiles = new Path[0];
		
		try {
			cacheFiles = DistributedCache.getLocalCacheFiles(context.getConfiguration());
		} catch (IOException ioe) {
			System.err.println("caught exception while getting cached files: " + StringUtils.stringifyException(ioe));
		}

		String cacheFile = cacheFiles[0].toString();
		try {
			loadRulesSets(cacheFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		//inizializzo il contatore di pagine
		this.contaPagine = 0;
				
	}

	
	@Override
	protected void cleanup(Context context) {
		
		//aggiungo a rule2null il conteggio del numero di pagine
		this.rule2null.put(new Text("numero_di_pagine_totale"), new IntWritable(this.contaPagine));
		
		//scrivo la mappa dei valori nulli
		try {
			context.write(new Text(""), this.rule2null);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void loadRulesSets(String cachePath) throws IOException {
		// note use of regular java.io methods here - this is a local file now
		List<List<String>> stringRulesSets = null;
		try {
			FileInputStream fileIn = new FileInputStream(cachePath);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			stringRulesSets = (List<List<String>>) in.readObject();
			in.close();
			fileIn.close();
		} catch(ClassNotFoundException c) {
			c.printStackTrace();
		}
		
		for (List<String> stringSet : stringRulesSets) {
			List<Rule> ruleSet = new LinkedList<Rule>();
			for (String stringRule : stringSet) {
				Rule regola = new XPathRule(stringRule);
				ruleSet.add(regola);
				this.rules.addRule(regola);
				this.rule2null.put(new Text(stringRule), new IntWritable(0));
			}
			this.rulesSets.add(ruleSet);
		}
		
	}
	
	@Override
	public void map(S3ObjectSummaryWritable key, S3ObjectWritable value, Context context) throws IOException, InterruptedException {
	    	
    	Map<Rule, String> result = new HashMap<Rule, String>();

    	Page p = new Page(IOUtils.toString(value.getObjectContent(), "UTF-8"));

    	for (Rule rule : this.rules.getAllRules()) {
			String estratto = rule.applyOn(p).getTextContent();
			result.put(rule, estratto);
			
			//se la regola non ha estratto un valore lo inserisco in rule2null
			if (estratto.equals("")) {
				Text regolaToText = new Text(rule.toString());
				IntWritable intValue = (IntWritable)this.rule2null.get(regolaToText);
				intValue.set(intValue.get() + 1);
			}
		}
		
		boolean rapr = addIfRepresentative(result);
		
        if (rapr) {
        	
        	MapWritable mappa = new MapWritable();
        	
//        	for (Rule regola : result.keySet()) {
//        		String valore = result.get(regola);
//        		if (valore != null) {
//        			mappa.put(new Text(regola.toString()), new Text(valore));
//        		} else {
//        			mappa.put(new Text(regola.toString()), new Text(""));
//        		}
//        	}

        	context.write(new Text(p.getContent()), mappa);
        }
        
        this.contaPagine++;
        
    }
    
    
    private boolean addIfRepresentative(Map<Rule, String> map) {
		boolean notSameValues = false;

		for (List<Rule> rules : this.rulesSets) {
			List<String> values = new ArrayList<String>();

			for (Rule r : rules) {
				values.add(map.get(r));
			}

			if (!sameValues(values)) {
				notSameValues = true;
			}

		}

		return notSameValues;

	}
    
    
    private boolean sameValues(List<String> values) {
		boolean same = true;
		String firstValue = values.get(0);
		for (String otherValues : values) {
			if (!firstValue.equals(otherValues)) {
				same = false;
				break;
			}
		}
		return same;
	}
    
    
//    private void removeSingleRuleRulesSets(){
//    	MaterializedRuleSet newRules = new MaterializedRuleSet();
//		for (List<Rule> rulesSet : this.rulesSets) {
//			if (rulesSet.size() == 0) {
//				this.rulesSets.remove(rulesSet);
//			} else {
//				for (Rule r : rulesSet)	newRules.addRule(r);
//			}
//		}
//		this.rules = newRules;
//    }


}

