package regoleCampioneUniversale;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import model.LabeledValue;
import model.Page;
import model.Rule;
import model.RuleSet;
import model.LabeledValue.Label;

import rules.dom.TextElements;
import rules.xpath.XPathRulesGenerator;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.StringUtils;
import org.w3c.dom.Node;

import com.atlantbh.hadoop.s3.io.S3ObjectSummaryWritable;
import com.atlantbh.hadoop.s3.io.S3ObjectWritable;

public class MapUCrules extends Mapper<S3ObjectSummaryWritable,S3ObjectWritable,Text,MapWritable> {
	
	static String S3_BUCKET_NAME = "s3.bucket.name";
	
//	private Map<String, Integer> nodeContent2occurrences;
	private int numPagine;
	private double correttezza;
//	private Integer uno;
	private LongWritable vuoto;
	private LongWritable numPagina;
	private Set<String> contentNodiTemplate;
	
	
	@Override
	protected void setup(Context context) {
		
//		this.nodeContent2occurrences = new HashMap<String, Integer>();
		this.numPagine = 0;
		this.correttezza = 1;
//		this.uno = new Integer(1);
		this.vuoto = new LongWritable();
		this.numPagina = new LongWritable();
				
//		//calcolo il template sul 10% delle pagine
//		List<Page> pagineCasuali = getRandomPages(context, 10);
//		this.contentNodiTemplate = getTemplateNodesContent(pagineCasuali);		
		
//		//leggo il template da file
//		Configuration conf = context.getConfiguration();
//		String nomeFileTemplate = conf.get("s3.template.filename");
//		String accessKeyId = conf.get("fs.s3n.awsAccessKeyId");
//		String secretAccessKey = conf.get("fs.s3n.awsSecretAccessKey");
//        AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
//		AmazonS3Client s3client = new AmazonS3Client(credentials);
//		String bucketName = "alf-emr";
//		String key = "template/"+nomeFileTemplate;
//		try {
//			S3Object file = s3client.getObject(bucketName, key);
//			S3ObjectInputStream s3ois = file.getObjectContent();
//			ObjectInputStream ois = new ObjectInputStream(s3ois);
//			this.contentNodiTemplate = (Set<String>)ois.readObject();
//			ois.close();
//			s3ois.close();
//		}catch(IOException i) {
//			i.printStackTrace();
//		}catch(ClassNotFoundException c) {
//			c.printStackTrace();
//		}
		
		//carico il template dalla DistributedCache
		Path[] cacheFiles = new Path[0];		
		try {
			cacheFiles = DistributedCache.getLocalCacheFiles(context.getConfiguration());
		} catch (IOException ioe) {
			System.err.println("caught exception while getting cached files: " + StringUtils.stringifyException(ioe));
		}		
		String cacheFile = cacheFiles[0].toString();
		loadTemplate(cacheFile);
		
	}
	
	
//	@Override
//	protected void cleanup(Context context) {
//		
//	}
	
	
	public void loadTemplate(String cachePath) {
		
		try {
			FileInputStream fileIn = new FileInputStream(cachePath);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			this.contentNodiTemplate = (Set<String>)in.readObject();
			in.close();
			fileIn.close();
		} catch(IOException i) {
			i.printStackTrace();
		} catch(ClassNotFoundException c) {
			c.printStackTrace();
		}
	
	}
	
	
	@Override
    public void map(S3ObjectSummaryWritable key, S3ObjectWritable value, Context context) throws IOException, InterruptedException {
    	
		this.numPagine++;
		this.numPagina.set(numPagine);
				
		//LongWritable contaPagine = new LongWritable(this.numPagine);
		
		Page p = new Page(IOUtils.toString(value.getObjectContent(), "UTF-8"));
		
		//estraggo dalla pagina tutti i nodi testuali
		TextElements textElements = new TextElements(p);		
		Set<Node> tuttiNodi = textElements.getAllTextNodes();
		    		
		Map<String, Integer> nodeCont2pageOcc = new HashMap<String, Integer>();
		    		
		//conto le occorrenze di ogni nodo nella pagina
		for (Node nodo : tuttiNodi) {
			String content = nodo.getTextContent();
			if (Pattern.matches("[ \t\r\n\f]+", content)) {
				//do nothing (è un nodo che contiene solo spazi)
			} else if (nodeCont2pageOcc.containsKey(nodo.getTextContent())) {
				int occorrenze = nodeCont2pageOcc.get(nodo.getTextContent());
				occorrenze++;
				nodeCont2pageOcc.put(nodo.getTextContent(), occorrenze);
			} else {
				nodeCont2pageOcc.put(nodo.getTextContent(), 1);
			}
		}
		    		
//		//seleziono i nodi "candidati" a essere di tipo template (che hanno una sola occorrenza nella pagina)
//		//e li inserisco/aggiorno nella relativa mappa
//		for (String content : nodeCont2pageOcc.keySet()) {
//			if (nodeCont2pageOcc.get(content).equals(this.uno)) {
//				if (this.nodeContent2occurrences.containsKey(content)) {
//					int occorrenze = this.nodeContent2occurrences.get(content);
//					occorrenze++;
//					this.nodeContent2occurrences.put(content, occorrenze);
//				} else {
//					this.nodeContent2occurrences.put(content, 1);
//				}
//			}
//		}
		
//		//creo la lista di nodi pivot (che stimo essere di tipo template)
//		Set<Node> pivotNodes = new HashSet<Node>();
//		for (Node nodo : tuttiNodi) {
//			String content = nodo.getTextContent();
//			if (this.nodeContent2occurrences.containsKey(content) &&
//					(this.nodeContent2occurrences.get(content).doubleValue()/this.numPagine > 0.6)) {
//				pivotNodes.add(nodo);
//			}
//		}
		
		//creo la lista di nodi pivot (che stimo essere di tipo template) e value (non del template)
		Set<Node> pivotNodes = new HashSet<Node>();
		for (Node nodo : tuttiNodi) {
			String content = nodo.getTextContent();
			if (this.contentNodiTemplate.contains(content)) {
				pivotNodes.add(nodo);
			}
		}
		
		MapWritable mappa = new MapWritable();
		
		//genero le regole e le inserisco in una mappa
		for (String content : nodeCont2pageOcc.keySet()) {
			
//			if (this.nodeContent2occurrences.containsKey(content) &&
//					(this.nodeContent2occurrences.get(content).doubleValue()/this.numPagine > 0.6)) {
//				//do nothing (è un nodo del template)
//			} else {
			if (!this.contentNodiTemplate.contains(content)) {
				
				int occorrenze = nodeCont2pageOcc.get(content);
				for (int j=1;j<=occorrenze;j++) {
				    LabeledValue LV = new LabeledValue(p, Label.CORRECT, content, j, this.correttezza);
					
				    XPathRulesGenerator generator = new XPathRulesGenerator(5);
					RuleSet setRegole = generator.inferValidRuleSet(LV, pivotNodes);
					
					for (Rule r : setRegole.getAllRules()){
						mappa.put(new Text(r.encode()), this.vuoto);
					}
					mappa.put(new Text("numeroPagina"), this.numPagina);
				}
				
			}
			
		}
		
		//scrivo la mappa con le regole
		context.write(new Text(p.getContent()), mappa);
		
	}
	
	
//	private List<Page> getRandomPages(Context context, int percentuale){
//		
//		Configuration conf = context.getConfiguration();
//		
//		String accessKeyId = conf.get("fs.s3n.awsAccessKeyId");
//        String secretAccessKey = conf.get("fs.s3n.awsSecretAccessKey");
//        AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
//		AmazonS3Client s3client = new AmazonS3Client(credentials);
//		
//		String bucket = conf.get(S3_BUCKET_NAME);
//		ObjectListing listing = s3client.listObjects(bucket);
//		List<S3ObjectSummary> listaFileSummary = listing.getObjectSummaries();
//		while(listing.isTruncated()){
//			listing = s3client.listNextBatchOfObjects(listing);
//			listaFileSummary.addAll(listing.getObjectSummaries());
//		}
//		
//		List<Page> pageList = new LinkedList<Page>();
//		for (int i = 0; i < (listaFileSummary.size()*percentuale)/100; i++){
//			Random random = new Random();
//			int randInt = random.nextInt(listaFileSummary.size());
//			String key = listaFileSummary.get(randInt).getKey();
//			S3Object file = s3client.getObject(bucket, key);
//			try { 
//				Page pagina = new Page(IOUtils.toString(file.getObjectContent(), "UTF-8"));
//				pageList.add(pagina);
//			} catch (IOException e) { e.printStackTrace(); }
//		}
//		
//		return pageList;
//	}
//	
//	
//	private Set<String> getTemplateNodesContent(List<Page> pagine){
//		
//		Map<String, Integer> nodeContent2occurrences = new HashMap<String, Integer>();
//		
//		for (Page p : pagine) {
//			//estraggo dalla pagina tutti i nodi testuali
//			TextElements textElements = new TextElements(p);		
//			Set<Node> tuttiNodi = textElements.getAllTextNodes();
//				    		
//			//conto le occorrenze di ogni nodo nella pagina
//			Map<String, Integer> nodeCont2pageOcc = new HashMap<String, Integer>();
//			for (Node nodo : tuttiNodi) {
//				String content = nodo.getTextContent();
//				if (Pattern.matches("[ \t\r\n\f]+", content)) {
//					//do nothing (è un nodo che contiene solo spazi)
//				} else if (nodeCont2pageOcc.containsKey(content)) {
//					int occorrenze = nodeCont2pageOcc.get(content);
//					occorrenze++;
//					nodeCont2pageOcc.put(content, occorrenze);
//				} else {
//					nodeCont2pageOcc.put(content, 1);
//				}
//			}
//			    		
//			//seleziono i nodi "candidati" a essere di tipo template (che hanno una sola occorrenza nella pagina)
//			//e li inserisco/aggiorno nella relativa mappa
//			for (String content : nodeCont2pageOcc.keySet()) {
//				if (nodeCont2pageOcc.get(content).equals(this.uno)) {
//					if (nodeContent2occurrences.containsKey(content)) {
//						int occorrenze = nodeContent2occurrences.get(content);
//						occorrenze++;
//						nodeContent2occurrences.put(content, occorrenze);
//					} else {
//						nodeContent2occurrences.put(content, 1);
//					}
//				}
//			}
//			
//		}
//		
//		//creo la lista di nodi pivot (che stimo essere di tipo template)
//		Set<String> pivotNodesContent = new HashSet<String>();
//		for (String content : nodeContent2occurrences.keySet()) {
//			if (nodeContent2occurrences.get(content).doubleValue()/pagine.size() > 0.6) {
//				pivotNodesContent.add(content);
//			}
//		}
//				
//		return pivotNodesContent;
//	}
	
}

