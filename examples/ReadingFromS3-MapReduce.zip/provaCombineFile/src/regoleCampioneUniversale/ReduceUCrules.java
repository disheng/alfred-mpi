package regoleCampioneUniversale;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class ReduceUCrules extends Reducer<Text,MapWritable,Text,MapWritable> {

//	private Map<String, Integer> regola2numPagine;
//	int numeroPagine;
	private Set<Text> allPageRules;
	private long numeroRegole;
	private MapWritable vuoto;
	private Map<Long, List<Long>> numPagina2numNuoveRegole;
	private Text numeroPagina;
	private MapWritable raprPage2numPage;
	
	
	@Override
	protected void setup(Context context) {
		
//		this.regola2numPagine = new HashMap<String, Integer>();
//		this.numeroPagine = 0;
		this.allPageRules = new HashSet<Text>();
		this.numeroRegole = 0;
		this.vuoto = new MapWritable();
		this.numPagina2numNuoveRegole = new HashMap<Long, List<Long>>();
		this.numeroPagina = new Text("numeroPagina");
		this.raprPage2numPage = new MapWritable();
				
	}
	
	
	@Override
	protected void cleanup(Context context) {
		
//		//scrivo le regole con associata la percentuale di pagine in cui sono state estratte
//		try {
//						
//			for (String regola : regola2numPagine.keySet()) {
//				double percentuale = (regola2numPagine.get(regola).doubleValue()/this.numeroPagine);
//				context.write(new Text(regola), new DoubleWritable(percentuale));
//			}
//			
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
		//creo il MapWritable con il numero di nuove regole per ogni pagina
		MapWritable numPage2numNewRule = new MapWritable();		
		for (Long numPagina : this.numPagina2numNuoveRegole.keySet()) {
			String numNewRule = "";
			List<Long> valori = this.numPagina2numNuoveRegole.get(numPagina);
			for (Long numNuoveRegole : valori) {
				numNewRule = numNewRule+" "+numNuoveRegole.toString();
			}
			numPage2numNewRule.put(new LongWritable(numPagina), new Text(numNewRule));
		}
		
		//scrivo le regole, la mappa coi numeri di nuove regole e la mappa della pagine "rappresentative"
		try {
			
			for (Text regola : this.allPageRules){
				context.write(regola, this.vuoto);
			}
			context.write(new Text("MapNumNuoveRegole"), numPage2numNewRule);
			context.write(new Text("PagineRappresentative"), this.raprPage2numPage);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Override
	public void reduce(Text key, Iterable<MapWritable> mappe, Context context) throws IOException, InterruptedException {
	
//		for (MapWritable mappa : mappe) {	
//						
//	    	for (Writable rule : mappa.keySet()) {
//	    		Text regola = (Text)rule;		    		
//	    		String content = regola.toString();    		
//	    		
//	    		if (regola2numPagine.containsKey(content)) {
//					int occorrenze = regola2numPagine.get(content);
//					occorrenze++;
//					regola2numPagine.put(content, occorrenze);
//				} else {
//					regola2numPagine.put(content, 1);
//				}
//	    		
//	    	}
//	    	
//	    	this.numeroPagine++;
//	    	
//		}
		
		long numRegoleOld;
		long numNuoveRegole;
		long numPagina = 0;
		
		for (MapWritable mappa : mappe) {
			
			numRegoleOld = this.numeroRegole;
			
			for (Writable rule : mappa.keySet()) {
				Text regola = (Text)rule;
				if (this.numeroPagina.equals(regola)){
					LongWritable numPage = (LongWritable)mappa.get(rule);
					numPagina = numPage.get();
				} else {
					this.allPageRules.add(regola);
				}
			}
						 
			this.numeroRegole = this.allPageRules.size();
			numNuoveRegole = this.numeroRegole - numRegoleOld;
			
			if ( this.numPagina2numNuoveRegole.containsKey(numPagina) ) {
				List<Long> valori = this.numPagina2numNuoveRegole.get(numPagina);
				valori.add(numNuoveRegole);
			} else {
				List<Long> valori = new LinkedList<Long>();
				valori.add(numNuoveRegole);
				this.numPagina2numNuoveRegole.put(numPagina, valori);
			}
			
			//se la pagina estrae nuove regole la inserisco tra le pagine "rappresentative"
			if (numNuoveRegole != 0) {
				this.raprPage2numPage.put(new Text(key.toString()),new LongWritable(numPagina));
			}
			
		}
		
    }
	
    	
}
