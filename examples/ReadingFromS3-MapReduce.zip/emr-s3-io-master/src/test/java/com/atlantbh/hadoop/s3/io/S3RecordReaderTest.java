package com.atlantbh.hadoop.s3.io;

import org.junit.Test;

/**
 * S3 record reader test
 * 
 * @author seljaz
 *
 */
public class S3RecordReaderTest {
	
	@Test
	public void testInitialize() {
		//TODO Not implemented
	}

	@Test
	public void testNextKeyValue() {
		//TODO Not implemented
	}
	
	public void testGetProgress() {
		//TODO Not implemented
	}
}
