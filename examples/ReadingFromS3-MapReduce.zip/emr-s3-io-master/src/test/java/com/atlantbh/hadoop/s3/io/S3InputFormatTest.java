package com.atlantbh.hadoop.s3.io;

import org.junit.Test;

/**
 * S3 Input Format test
 * 
 * @author seljaz
 *
 */
public class S3InputFormatTest {
	
	@Test
	public void testGetSplits() {
		//TODO Not implemented
	}
}
